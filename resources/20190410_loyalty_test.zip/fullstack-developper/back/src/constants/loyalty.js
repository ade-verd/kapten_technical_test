'use strict';

const loyaltyStatuses = ['bronze', 'silver', 'gold', 'platinum'];

module.exports = {
  loyaltyStatuses,
};
